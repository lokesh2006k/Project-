Employee Management Dashboard

Login:
Email: admin@gmail.com
Password: 1234

Features:
- Login Authentication
- Dashboard
- Add Employee
- Delete Employee
- LocalStorage Token
