let employees = [];

function login() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if(email === "admin@gmail.com" && password === "1234") {
        localStorage.setItem("token", "jwt-token");
        document.getElementById("loginPage").classList.add("d-none");
        document.getElementById("dashboardPage").classList.remove("d-none");
    } else {
        alert("Invalid Login");
    }
}

function logout() {
    localStorage.removeItem("token");
    location.reload();
}

function addEmployee() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("empEmail").value;
    let department = document.getElementById("department").value;

    employees.push({name,email,department});
    displayEmployees();

    document.getElementById("name").value = "";
    document.getElementById("empEmail").value = "";
    document.getElementById("department").value = "";
}

function displayEmployees() {
    let table = document.getElementById("employeeTable");
    table.innerHTML = "";

    employees.forEach((emp,index)=>{
        table.innerHTML += `
        <tr>
            <td>${emp.name}</td>
            <td>${emp.email}</td>
            <td>${emp.department}</td>
            <td>
                <button class="btn btn-danger btn-sm" onclick="deleteEmployee(${index})">Delete</button>
            </td>
        </tr>`;
    });
}

function deleteEmployee(index) {
    employees.splice(index,1);
    displayEmployees();
}

window.onload = function() {
    if(localStorage.getItem("token")) {
        document.getElementById("loginPage").classList.add("d-none");
        document.getElementById("dashboardPage").classList.remove("d-none");
    }
}
